@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp001-SUA_TU_DONG.ps1"
if errorlevel 1 (echo LOI: Chua cap nhat. & pause & exit /b 1)
echo Hoan tat. Kiem tra trong Chrome, sau do day Github.
pause
