@echo off
cd /d "C:\Users\Surface\Documents\tienghanmrlee.github.io"
git status --short
echo.
echo Se chi commit 3 file: index.html, mrlee-slide.js, mrlee-slide.css
git diff --stat -- index.html mrlee-slide.js mrlee-slide.css
echo.
set /p OK=Nhap DAY de commit/push, hoac N de huy: 
if /i not "%OK%"=="DAY" (echo Da huy. & pause & exit /b 0)
git commit --only -m "Fix 9 original banners autoplay every 2 seconds" -- index.html mrlee-slide.js mrlee-slide.css
if errorlevel 1 (echo Commit khong thanh cong. & pause & exit /b 1)
git push origin main
if errorlevel 1 (echo Push that bai. & pause & exit /b 1)
echo DAY GITHUB THANH CONG
pause
