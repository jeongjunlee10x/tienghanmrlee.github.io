﻿param(
  [string]$Website = 'C:\Users\Surface\Documents\tienghanmrlee.github.io'
)
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $base 'FILES'
$index = Join-Path $Website 'index.html'
if (-not (Test-Path -LiteralPath $index -PathType Leaf)) { throw "Khong tim thay trang chu: $index" }
$html = [System.IO.File]::ReadAllText($index, [System.Text.Encoding]::UTF8)
if ($html -notmatch 'id=["'']mrleeBanner9["'']') { throw 'Trang chu chua co banner 9 anh (mrleeBanner9). Can khoi phuc 9 anh truoc.' }
if (([regex]::Matches($html, 'class="mrlee-banner9-slide')).Count -ne 9) { throw 'Trang chu khong co dung 9 slide; khong cap nhat.' }
foreach ($n in 1..9) {
  if (-not (Test-Path -LiteralPath (Join-Path $Website "images\$n.png") -PathType Leaf)) { throw "Thieu images\$n.png. Can khoi phuc anh truoc." }
}
$backupBase = Join-Path (Split-Path -Parent $Website) 'MRLEE-BACKUP-BANNER-V4'
$backup = Join-Path $backupBase (Get-Date -Format 'yyyyMMdd-HHmmss')
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($f in @('index.html','mrlee-slide.js','mrlee-slide.css')) {
  $src = Join-Path $Website $f
  if (Test-Path -LiteralPath $src -PathType Leaf) { Copy-Item -LiteralPath $src -Destination (Join-Path $backup $f) -Force }
}
# Always refresh both asset URLs, even if an older version already exists. Avoid browser cache.
$newStyle = '<link rel="stylesheet" href="mrlee-slide.css?v=auto-v4-20261013" data-mrlee-slide="css">'
$newScript = '<script defer src="mrlee-slide.js?v=auto-v4-20261013" data-mrlee-slide="js"></script>'
$styleRegex = '<link\b(?=[^>]*mrlee-slide\.css)[^>]*>'
$scriptRegex = '<script\b(?=[^>]*mrlee-slide\.js)[^>]*>\s*</script>'
if ([regex]::IsMatch($html,$styleRegex)) { $html = [regex]::Replace($html,$styleRegex,$newStyle) }
else { $html = $html.Replace('</head>',"  $newStyle`r`n</head>") }
if ([regex]::IsMatch($html,$scriptRegex)) { $html = [regex]::Replace($html,$scriptRegex,$newScript) }
else { $html = $html.Replace('</body>',"  $newScript`r`n</body>") }
if (($html -notmatch 'mrlee-slide\.js\?v=auto-v4-20261013') -or ($html -notmatch 'mrlee-slide\.css\?v=auto-v4-20261013')) { throw 'Loi nhung CSS/JS banner; da dung.' }
[System.IO.File]::WriteAllText($index,$html,(New-Object System.Text.UTF8Encoding($false)))
Copy-Item -LiteralPath (Join-Path $source 'mrlee-slide.js') -Destination (Join-Path $Website 'mrlee-slide.js') -Force
Copy-Item -LiteralPath (Join-Path $source 'mrlee-slide.css') -Destination (Join-Path $Website 'mrlee-slide.css') -Force
Write-Host "DA SUA: Banner 9 anh tu dong chuyen sau moi 2 giay." -ForegroundColor Green
Write-Host "WEBSITE: $Website"
Write-Host "SAO LUU: $backup"
Write-Host 'Khong sua anh goc, 4 nut chinh, logo, hoc vien hay Firebase.'
