param([string]$Website='C:\Users\Surface\Documents\tienghanmrlee.github.io')
$ErrorActionPreference='Stop'
$files=@('hoc-theo-bai.html','mrlee-advanced-lesson-data.js','mrlee-lesson-page.js','mrlee-v6-vocab.css','mrlee-sc-lesson-data.js')
foreach($f in $files){if(-not (Test-Path -LiteralPath (Join-Path $Website $f))){throw "Chua co file: $f"}}
$html=[IO.File]::ReadAllText((Join-Path $Website 'hoc-theo-bai.html'))
if(-not ($html.Contains('mrlee6-v6') -and $html.Contains('mrlee-v6-vocab.css'))){throw 'HTML chua nap V6.'}
$data=[IO.File]::ReadAllText((Join-Path $Website 'mrlee-advanced-lesson-data.js'))
if(-not $data.Contains('export const ADVANCED_LESSONS')){throw 'Thieu du lieu Trung-Cao cap.'}
if(Get-Command node -ErrorAction SilentlyContinue){
 foreach($f in @('mrlee-advanced-lesson-data.js','mrlee-lesson-page.js')){
  node --check (Join-Path $Website $f)
  if($LASTEXITCODE -ne 0){throw "JS loi cu phap: $f"}
 }
}
Write-Host 'OK: HTML V6 + dữ liệu + JavaScript đã sẵn sàng.' -ForegroundColor Green
Start-Process (Join-Path $Website 'hoc-theo-bai.html')
