@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp003-KIEM_TRA.ps1"
echo.
pause
